<?php global $Theme9; ?>

	<?php
	 get_header(); 
	 // Template Name: Contact Template
	 ?>

<section class="right-side-content">	
	<div class="container-fluid">

		<?php if( $Theme9['con-page-show/hide'] == 1 ) : ?>
		 <div class="theme9-page-title">
			<h2><?php echo $Theme9['add-con-title']; ?></h2>
		</div>
		<?php endif; ?>

	   <div class="theme9-section-content">
	   	 <div class="theme-con-feature">
		  	<img src="<?php echo $Theme9['featured-img']['url'] ?>" alt="Contact-Feature">
		  </div>	
			<div class="row">
			 <div class="col-md-6">
				<div class="address-info">
				  <div class="address">
				       <h5><?php echo $Theme9['address-type'] ?> : </h5>
					      <p> <?php echo $Theme9['address'] ?></p>
				  </div>
				</div>
			 </div>
			 <div class="col-md-6">
			   <div class="phone-mail">
				     <span><?php echo $Theme9['email-icon'] ?></span>
				    <h4> <?php echo $Theme9['email-address'] ?> </h4>
					<span><?php echo $Theme9['phone-icon'] ?></span>
				    <h4><?php echo $Theme9['phone-number'] ?></h4>
			   </div>
			 </div>		 			
			</div>
			<div class="theme9-con-form">
				<?php echo $Theme9['contact-form'] ?>
			</div>
		</div>


		<?php get_template_part("theme9_widgets"); ?>
		
		<?php get_footer(); ?>