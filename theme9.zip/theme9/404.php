
	
	<?php get_header(); ?>

<!--=======right-content========-->
<section class="right-side-content">
	<div class="container-fluid">
	  <div class="erorrpage-content">
		 <div class="erorr-content-item">
		 <i class="fas fa-exclamation"></i>
        <h2>Found Nothing We Have</h2>
        <h4>SORRY, WE COULDN'T FIND anything</h4>
        <a href="http://localhost/learnwp/">back to home</a>
      </div>
	</div>	
		
	<?php get_footer(); ?>


