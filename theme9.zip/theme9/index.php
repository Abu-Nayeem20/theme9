	
	<?php get_header(); ?>

<!--=======right-content========-->
<section class="right-side-content">
	<div class="container-fluid">
		<div class="row">
			<?php
			    if(have_posts()):
				    while (have_posts()): the_post();
		      ?>
			 <div class="col-md-6">	
				<div class="theme9-post-cotent">
					<div class="post-content-title">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</div>
					<div class="post-featured-image">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					</div>
					<div class="post-date">
						<em><?php echo get_the_date(); ?></em>
					</div>
					<div class="post-content-text">
						<?php theme9_readmore(20); ?>
						<a href="<?php the_permalink(); ?>">....read more</a>
					</div>
				</div>
			</div>
			<?php
				 endwhile;
				 else: echo 'NO POST';
			    endif;	
			 ?>
		</div>
		<div class="theme9-pagination">
		   <?php the_posts_pagination(array(
             'screen_reader_text' => " ",
             'prev_text' => '<i class="fas fa-angle-left"></i>',
             'next_text' => '<i class="fas fa-angle-right"></i>'
           ));
           ?>
		</div>
		<?php get_template_part("theme9_widgets"); ?>
		
		<?php get_footer(); ?>