
	<?php
	 get_header(); 
	 	// Template Name: Custom Template
	 ?>

<section class="right-side-content">
	<div class="container-fluid">
		
		<div class="theme9-page-title">
			<h2><?php the_title(); ?></h2>
		</div>
		<div class="theme9-section-content">
			<div class="row">

			<?php
				$paged = get_query_var('paged')?get_query_var('paged'):1;
				$theme9_post_per_page = 2;

				$theme9_post = new WP_Query(array(
					'posts_per_page' => $theme9_post_per_page,
					'paged' => $paged,
					'meta_query' => array(
					 	'relation' => 'AND',
					 	array(
					 		'key' => 'featured',
					 		'value' => '1',
					 		'compare' => '='
					 	),
					 	array(
					 		'key' => 'new',
					 		'value' => '1',
					 		'compare' => '='
					 	)
					 )
				));

				while ( $theme9_post->have_posts()) {
					$theme9_post->the_post();
				
			?>	

			 <div class="col-md-10 offset-md-1">	
				<div class="theme9-post-cotent">
					<div class="post-content-title">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</div>
					<div class="post-featured-image">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					</div>
					<div class="post-content-text-page">
						<?php the_excerpt(); ?>
					</div>
				</div>
			</div> 

			<?php
				}
				wp_reset_query();
			?>

			</div>
			<div class="theme9-pagination">
		   <?php
		   		echo paginate_links(array(
		   			'total' => $theme9_post->max_num_pages,
		   			'current' => $paged,
		   			'prev_text' => '<i class="fas fa-angle-left"></i>',
                    'next_text' => '<i class="fas fa-angle-right"></i>'
		   		));
           ?>
		</div>
		</div>

		<?php get_template_part("theme9_widgets"); ?>
		
		<?php get_footer(); ?>
		