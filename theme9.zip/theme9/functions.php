<?php

// setup
function theme9_setup(){
	load_theme_textdomain("theme9", get_theme_file_path('/language') );
	add_theme_support("title-tag");
	add_theme_support("post-thumbnails");
	add_image_size('theme9-imgs-1', 400, 400, array('left', 'top'));
	add_image_size('theme9-imgs-2', 450, 450, array('right', 'top'));
	add_image_size('theme9-imgs-3', 500, 500, array('center', 'center'));
	add_theme_support('post-formats', array(
		'image', 'audio', 'video', 'quote', 'link'
	));
	$theme9_logo_size = array(
		'width' => '250',
		'height' => '100',
		'flex-height' => true,
		'flex-width' => true
	);
	add_theme_support("custom-logo", $theme9_logo_size);
	register_nav_menus(array(
		'main-menu' => __('Main Menu','theme9'),
		'secondary-menu' => __('Secondary Menu','theme9')
	));
}
 add_action("after_setup_theme","theme9_setup");

// Assets

function theme9_assets(){
	// css
	wp_enqueue_style('dashicon');
	wp_enqueue_style("animatecss", get_theme_file_uri('/css/animate.min.css'),'',' 1.0.0');
	wp_enqueue_style("owlcss", get_theme_file_uri('/css/owl.carousel.min.css'),'',' 1.1.0');
	wp_enqueue_style("old-fws",'//stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
	wp_enqueue_style("bootstrapcss",'//stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css');
	wp_enqueue_style("maincss", get_stylesheet_uri(),'','1.0.0');
	wp_enqueue_style("responsivecss", get_theme_file_uri('/css/responsive.css'),'',' 1.1.0');

	// js

	wp_enqueue_script("fontawesomejs", "//kit.fontawesome.com/20572c93fb.js", array("jquery"), "1.0,1", true);

	wp_enqueue_script("popperjs", "//cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js", array("jquery"), "1.0,1", true);

	wp_enqueue_script("bootstrapjs", "//stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js", array("jquery"), "1.0,1", true);

	wp_enqueue_script("wowjs", get_theme_file_uri("/js/wow.min.js"), array("jquery"), "1.0,0", true);
	wp_enqueue_script("owljs", get_theme_file_uri("/js/owl.carousel.min.js"), array("jquery"), "1.0,1", true);

	wp_enqueue_script("mainjs", get_theme_file_uri("/js/main.js"), array("jquery"), "1.0,2", true);
}
 add_action("wp_enqueue_scripts","theme9_assets");


// footer widgets
function theme9_footer_widgets(){
	register_sidebar(array(
		'name' => 'Footer 1',
		'id' => 'footer-1',
		'before_widget' => '<div class="footer-widget">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
	register_sidebar(array(
		'name' => 'Footer 2',
		'id' => 'footer-2',
		'before_widget' => '<div class="footer-widget">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
	register_sidebar(array(
		'name' => 'Footer 3',
		'id' => 'footer-3',
		'before_widget' => '<div class="footer-widget">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>'
	));
}

add_action('widgets_init','theme9_footer_widgets');

// Read More
function theme9_readmore($words){
	$theme9_postcontent = explode(' ',get_the_content());
	$theme9_postcontent_slice = array_slice($theme9_postcontent,0,$words);
	echo implode(' ', $theme9_postcontent_slice);
}





 // Redux

  require_once('lib/redux-core/framework.php');
  require_once('lib/sample/config.php');

 // Attachments

  if ( class_exists( 'Attachments' ) ) {
    require_once('lib/attach/attachments.php');
  }

  // TGM activition

  require_once ( get_theme_file_path('/inc/tgm.php') );

// CSF

 require_once ( get_theme_file_path('/inc/csf/codestar-framework.php') );
 require_once ( get_theme_file_path('/inc/csf.php') );

// For image size
 function theme9_img_srcset(){

 }
 add_filter('wp_calculate_image_srcset', 'theme9_img_srcset');














?>