<?php global $Theme9; ?>

<footer class="theme9-footer">
	<div class="row">
		<div class="col-6">
			<div class="footer-left">
				<?php echo $Theme9['copyr-icon']; ?>
				<span><?php echo $Theme9['copyr-text']; ?></span>
			  </div>	
			</div>
			<div class="col-6">
			  <div class="footer-right">
				 <div class="social-links">

				 <?php if(!empty($Theme9['social-links']['Facebook'])) : ?>
	      		     <a href="<?php echo $Theme9['social-links']['Facebook']; ?>"><i class="fab fa-facebook-f"></i></a>
	      		 <?php endif; ?> 
	      		  
	      		 <?php if(!empty($Theme9['social-links']['Twitter'])) : ?>   
	      		     <a href="<?php echo $Theme9['social-links']['Twitter']; ?>"><i class="fab fa-twitter"></i></a>
	      		 <?php endif; ?>

	      		 <?php if(!empty($Theme9['social-links']['LinkedIn'])) : ?>    
	      		     <a href="<?php echo $Theme9['social-links']['LinkedIn']; ?>"><i class="fab fa-linkedin-in"></i></a>
	      		 <?php endif; ?>

	      		 <?php if(!empty($Theme9['social-links']['Instagram'])) : ?>    
	      		     <a href="<?php echo $Theme9['social-links']['Instagram']; ?>"><i class="fab fa-instagram"></i></a>
	      		 <?php endif; ?>    

	      		 <?php if(!empty($Theme9['social-links']['Google+'])) : ?>
	      		     <a href="<?php echo $Theme9['social-links']['Google+']; ?>"><i class="fab fa-google-plus-g"></i></a>
	      		 <?php endif; ?>     

	      	         </div>
				  </div>
				</div>
			</div>
		</footer>
	</div>
</section>


<!--=======Content-End========-->
   
	<?php wp_footer(); ?>
</body>
</html>