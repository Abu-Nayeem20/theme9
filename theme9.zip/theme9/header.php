<?php global $Theme9; ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale= 1">
	<meta http-equiv="X-UA-compitable" content="IE-edge">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!--=======Content-Start========-->

<!--=======left-content========-->
 <header class="left-side-content">

 	<!-- -------header top----- -->
<div class="header-top">
	<div class="container-fluid">
		<div class="row">
			<div class="col-4">
				<div class="theme9-logo">
					<?php the_custom_logo(); ?>
				</div>
			</div>
			<div class="col-8">
				<div class="menu-icon">
					<?php echo $Theme9['menu-icon-i']; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- -------Profile----- -->
<div class="theme9-dev-profile">
	<div class="my-profile-img">
	     <img src="<?php echo $Theme9['profile-img']['url'] ?>" alt="Nayeem Islam">
	    </div> 
	     <div class="profile-text">
	       <h2> <?php echo $Theme9['profile-heding']; ?></h2>
	       <h5> <?php echo $Theme9['profile-des']; ?></h5>
	      </div>
	      <nav class="theme9-main-menu">
		  <?php
		  	wp_nav_menu(array(
		  		'theme_location' => 'main-menu'
		  	));
		   ?>
	</nav>
</div>
 	<!-- -------slider----- -->
	 	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	  <ol class="carousel-indicators">
	    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
	    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
	    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
	  </ol>
	  <div class="carousel-inner">
	    <div class="carousel-item active">
	      <img src="<?php echo $Theme9['slide-1']['url'] ?>" class="d-block w-100" alt="Slider Image">
	    </div>
	    <div class="carousel-item">
	      <img src="<?php echo $Theme9['slide-2']['url'] ?>" class="d-block w-100" alt="Slider Image">
	    </div>
	    <div class="carousel-item">
	      <img src="<?php echo $Theme9['slide-3']['url'] ?>" class="d-block w-100" alt="Slider Image">
	    </div>
	  </div>
	</div>
 </header>