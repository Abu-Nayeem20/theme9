(function ($) {
    'use strict'


$(".menu-icon").on("click", function () {
    $(".theme9-dev-profile").slideToggle();
});


// owl carousel for portfolio

$('.team-member-slider .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
});

// owl carousel for testimonials
$('.theme9-testimonial-slider .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    autoplayTimeout:10000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

// owl carousel for about slider
$('.theme9-about-slider .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    autoplayTimeout:6000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

// This code for wow.js
new WOW().init();

// 404 page

$('.right-side-content').on('mouseover', function () {
    $(".erorr-content-item i").css({"display":"block"});
});



}) (jQuery);


















