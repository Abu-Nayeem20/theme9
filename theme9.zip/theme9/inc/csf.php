<?php

if( class_exists( 'CSF' ) ) {

  // Set a unique slug-like ID
  $prefix = 'theme9_framework';

  // Create options
  CSF::createOptions( $prefix, array(
    'menu_title' => 'Theme Nine',
    'menu_slug'  => 'theme-nine',
    'framework_title' => __('Theme Nine Options', 'theme9'),
    'menu_icon' => 'dashicons-admin-multisite'
  ) );

  // Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'Header',
    'fields' => array(

      // A text field
      array(
        'id'    => 'header-text',
        'type'  => 'text',
        'title' => 'Header Text',
      ),
      array(
        'id'    => 'header-img',
        'type'  => 'media',
        'title' => 'Header Image',
      ),
      array(
        'id'    => 'header-desc',
        'type'  => 'textarea',
        'title' => 'Header Description',
      ),


    )
  ) );

// Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'Footer',
    'fields' => array(

      // A text field
      array(
        'id'    => 'footer-text',
        'type'  => 'text',
        'title' => 'Footer Text',
      ),
      array(
        'id'    => 'footer-img',
        'type'  => 'media',
        'title' => 'Footer Image',
      ),
      array(
        'id'    => 'footer-desc',
        'type'  => 'textarea',
        'title' => 'Footer Description',
      ),


    )
  ) );  


  // Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'Group Ex',
    'fields' => array(

      // A text field
      array(
        'id'    => 'group-example',
        'type'  => 'group',
        'title' => 'Group Example',
        'fields' => array(
          array(
            'id' => 'group-title',
            'type' => 'text',
            'title' => 'Add Your Title'
          ),
          array(
            'id' => 'group-content',
            'type' => 'textarea',
            'title' => 'Add Your Content'
          )
        )
      ),
    )
  ) );

    // Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'Social Network',
    'fields' => array(

      // A text field
      array(
        'id'    => 'social-net',
        'type'  => 'group',
        'title' => 'Social Accounts',
        'fields' => array(
          array(
            'id' => 'social-icon',
            'type' => 'icon',
            'title' => 'Add Your Icon'
          ),
          array(
            'id' => 'social-url',
            'type' => 'text',
            'title' => 'Add URL'
          )
        )
      ),
    )
  ) );  

 

}































