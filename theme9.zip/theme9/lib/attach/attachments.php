<?php 
	define( 'ATTACHMENTS_SETTINGS_SCREEN', false );
	add_filter( 'attachments_default_instance', '__return_false' );

	// Portfolio

 function theme9_portfolio($attachments){
 	$fields = array(
 		array(
 			'name' => 'name',
 			'type' => 'text',
 			'label' => __('Project Name', 'theme9')
 		),
 		array(
 			'name' => 'url',
 			'type' => 'text',
 			'label' => __('Project URL', 'theme9')
 		),
 		array(
 			'name' => 'about',
 			'type' => 'textarea',
 			'label' => __('Project Description', 'theme9')
 		)
 	);

 	$args = array(
 		'label' => 'Portfolio',
 		'post_type' => array( 'page' ),
 		'file_type' => array( 'image' ),
 		'note' => 'Add your portfolios',
 		'button_text' => 'Add Portfolio',
 		'fields' => $fields
 	);

  $attachments->register( 'portfolio', $args );

 }	

 add_action( 'attachments_register', 'theme9_portfolio' );

 		// Testimonials

function theme9_testimonials($attachments){
 	$fields = array(
 		array(
 			'name' => 'name',
 			'type' => 'text',
 			'label' => __('Name', 'theme9')
 		),
 		array(
 			'name' => 'desi',
 			'type' => 'text',
 			'label' => __('Designation', 'theme9')
 		),
 		array(
 			'name' => 'about',
 			'type' => 'textarea',
 			'label' => __('About', 'theme9')
 		)
 	);

 	$args = array(
 		'label' => 'Testimonials',
 		'post_type' => array( 'page' ),
 		'file_type' => array( 'image' ),
 		'note' => 'Add your testimonials',
 		'button_text' => 'Add Testimonial',
 		'fields' => $fields
 	);

  $attachments->register( 'testimonials', $args );
  
 }	

 add_action( 'attachments_register', 'theme9_testimonials' );


















