<?php global $Theme9; ?>

	<?php
	 get_header(); 
	 // Template Name: About Template
	 ?>

<section class="right-side-content">

		<div class="theme9-about-slider">
		<div class="owl-carousel owl-theme">

			<?php
				$theme9_about_slider = $Theme9['about-slide'];
				foreach($theme9_about_slider as $theme9_about_slides) {
			?>

			 <div class="item">
				<div class="theme9-about-slide">
					<div class="about-slide-img">
						<img src="<?php echo $theme9_about_slides['image']; ?>" alt="Image">
						<div class="about-slide-text">
				  		<div class="about-slide-heading wow slideInUp">
				    	<h2> <?php echo $theme9_about_slides['title']; ?> </h2>
				   		</div>
				   		<div class="about-slide-tagline wow slideInUp">
				     	<p> <?php echo $theme9_about_slides['description']; ?> </p>
				       </div>
				  	</div>
				  </div>
				</div>
			</div>

			<?php
				}
			?>

		</div>
	</div>
	
	<div class="container-fluid">
		
		<?php if( $Theme9['ab-page-show/hide'] == 1 ) : ?>
		 <div class="theme9-page-title">
			<h2><?php echo $Theme9['add-ab-title']; ?></h2>
		</div>
		<?php endif; ?>

		<div class="theme9-section-content">
			<div class="row">
				<div class="col-md-6">
					 <div class="theme9-about-image">
						<img src="<?php echo $Theme9['about-img-1']['url'] ?>" alt="About-Image">
					  </div>
					  </div>
					  <div class="col-md-6">
					  <div class="theme9-about-text">
						 <p><?php echo $Theme9['about-text-1']; ?></p>
					</div>
				</div>

				<?php if( $Theme9['about-show/hide-2'] == 1 ) : ?>
				<div class="col-md-6">
					  <div class="theme9-about-text">
						 <p><?php echo $Theme9['about-text-2']; ?></p>
					</div>
				</div>
				<div class="col-md-6">
				   <div class="theme9-about-image">
					   <img src="<?php echo $Theme9['about-img-2']['url'] ?>" alt="About-Image">
					</div>
				</div>
				<?php endif; ?>			
			</div>
		</div>


		<?php get_template_part("theme9_widgets"); ?>
		
		<?php get_footer(); ?>